import styles from "./Contact.module.scss";
 import pic2 from "../public/planning.jpg";

import Image from "next/image";
 const Contact = () => {
  return (
<div className={styles.contactContainer}>
  <div className={styles.section1}>
    <h1>Contact Us</h1>
    <h3>LET'S CONNECT</h3>
    <h2>Drop us your message and we will back to you as soon as possible </h2>
    <div className={styles.form}>
      <div className={styles.row1}>
      <label for="fname">First Name</label>
      <input type="text" id="fname" name="firstname" placeholder="First Name" required/>
      <label for="email">Email Address</label>
      <input type="text" id="email" name="lastname" placeholder="example@gmail.com" required/>
     
      
      </div>
      <div className={styles.row2}>
      <label for="fname">Last Name</label>
      <input type="text" id="lname" name="lastname" placeholder="Last Name" required/>
      
      <label for="phonenumber">Phone Number</label>
       <input type="digit" id="phone" name="phonenumber" placeholder="Your Phone Number"  required/>
       
      </div>
     
    </div>
    <div className={styles.row3}>
      <label for="message">Message</label>
       <textarea id={styles.message} name="Write here" placeholder="Write here..." style={{height:"200px"}} required></textarea>
       <button type="submit" value="Send Message">
      Send Message
      </button>
      
      </div>
     
  </div>
{/* Second Division of contact */}
       <div className={styles.heading}>
        
         <p>KEEP IN TOUCH</p>
         <h3>
           LET'S START A FRUITFUL <br /> CONVERSATION.
         </h3>
       </div>

       {/* <h3>LET'S START A FRUITFUL CONVERSATION.</h3> */}

       <div className={styles.contact}>
         <div className={styles.connect}>
           <div className={styles.cicon}>
             <div className={styles.icons}>
               <Image src={"/icon_phone.png"} layout={"fill"} />
             </div>
             <div className={styles.icons}>
               <Image src={"/icon_mail.png"} layout={"fill"} />
             </div>
             <div className={styles.icons}>
               <Image src={"/icon_location.png"} layout={"fill"} />
             </div>
           </div>
           <div className={styles.info}>
             <div className={styles.cinfo}>
               <h3>Call Us 24/7</h3>
               <p>(+1)800-600-2323</p>
             </div>
             <div className={styles.cinfo}>
               <h3>Mail Us 24/7 </h3>
               <p>Info@rengebxweb.co.in</p>
             </div>
             <div className={styles.cinfo}>
               <h3>Visit Us 24/7</h3>
               <p> 1508 North Street, AustinTexas,US</p>
             </div>
           </div>
         </div>

         <div className={styles.cimage}>
           <Image
            src={pic2}
            width={597}
            height={895}
            style={{
              marginTop: "8%",
            }}
          />
        </div>
      </div>
      <div className={styles.followus}>
          <h3>Follow us on</h3>

          <div className={styles.Sicons}>
           
            <div className={styles.icons}>
              <Image src={"/facebook_i.png"} width={45} height={45} />
            </div>
            <div className={styles.icons}>
              <Image src={"/insta_i.png"} width={45} height={45} />
            </div>
            <div className={styles.icons}>
              <Image src={"/linkedin_i.png"} width={45} height={45} />
            </div>
            <div className={styles.icons}>
              <Image src={"/twitter_i.png"} width={45} height={45} />
            </div>
          </div>
</div>
</div>
    
  );
};

 export default Contact;
