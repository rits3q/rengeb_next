import pic from "../public/images/img1.jpg"
import Image from "next/image"
import styles from "../styles/Home.module.css"
const Home =()=>{
    return(
        <div>
             <h1>Hello, I'm Rengeb</h1>
        <div className={styles.image} >
          
            <Image  
            src={pic}
            width={500}
        height={500}
        priority
        // style={{
        //     alignItems:"right"
        //   }}
          
        />
       
        </div>
        </div>
    )
}
export default Home