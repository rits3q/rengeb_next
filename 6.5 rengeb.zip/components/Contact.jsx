import styles from "Contact.module.scss";

const Contact = () => {
  return <h1>Contact</h1>;
};

export default Contact;
