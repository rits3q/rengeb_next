import styles from "./Service.module.scss";

const Service = () => {
  return <h1>Service</h1>;
};

export default Service;
