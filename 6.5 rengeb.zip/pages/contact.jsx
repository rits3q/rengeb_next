import Contact from "../components/Contact";
const contact = () => {
  return <Contact></Contact>;
};

export default contact;
