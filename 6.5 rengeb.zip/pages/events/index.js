function Event(){
    return ( <div>
        <h1>Event planned </h1>
    </div>
    )
}

export default Event;