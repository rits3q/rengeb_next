//more than one dynamic parameter than it will not clash like \../..
//http://localhost:3000/events/2/rit
function FilteredEvent(){
    return (
        <div>
            <h1>Filtered Event</h1>
        </div>
    )
}
export default FilteredEvent;