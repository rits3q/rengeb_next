function EventDetail(){
    return (
        <div>
            <h1>Events EventDetail</h1>
        </div>
    )
}

export default EventDetail;