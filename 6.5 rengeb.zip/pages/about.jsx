import About from "../components/About";

const about = () => {
  return <About></About>;
};

export default about;
