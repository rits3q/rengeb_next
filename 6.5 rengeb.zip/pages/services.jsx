import Service from "../components/Service";

const service = () => {
  return <Service></Service>;
};

export default service;
