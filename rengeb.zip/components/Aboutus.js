import styles from '../components/Aboutus.module.css'
import pic from '../public/images/img1.jpg'
import pic2 from '../public/images/planning.jpg'
import Image from "next/image"
import Link from 'next/link'
export default function Aboutus() {
    return (
       <div className={styles.container}>
                       
          <div className={styles.aboutus}> 
          <h1 className={styles.about}>ABOUT US </h1>
          <h5 id={styles.abt3}> WHO WE ARE </h5>
          
          <h3>Hey guys, have a look at my work and designs on my website.<br/>Don't forget to look into my previous project.
    </h3>
          <h5>We basically provide five types of services i.e., Renovation, Plastering ,Masonry ,Flooring and Roofing.
              We are proud to deliver projects which meets the present day needs for housing
              <br/> and infrastructurewithout compromising the ability of future generations.
          <br/>We believe each commercial building renovation project must be planned and executed carefully.
          </h5>
          <h5>We basically provide five types of services i.e., Renovation, Plastering ,Masonry ,Flooring and Roofing.
              We are proud to deliver projects which meets the present day needs for housing
              <br/> and infrastructurewithout compromising the ability of future generations.
          <br/>We believe each commercial building renovation project must be planned and executed carefully.
          </h5>
          
          <ul>
          <button class="btn #ff5722 deep-orange">View Our Services</button> 
          </ul>
  </div>
  <div className={styles.column}>
  
      <Image  
            src={pic}
            className={styles.image}
            width={500}
            height={250}
            layout="responsive"
            
        priority
        />
        
        <div className={styles.row}> 
        <div class="row">
      <div class="col s4"><h1 id="digits">350+</h1><h5 style={{ color:"white" }}>Trusted Clients</h5> </div>
      <div class="col s4"><h1 id="digits">215+</h1><h5 style={{ color:"white" }}>Finished Project</h5></div>
      <div class="col s4"><h1 id="digits">215+</h1><h5 style={{ color:"white" }}>Years Of Experience</h5></div>
      </div>
      
        </div>
        
</div>
<div className={styles.followus}>
        <p style={{ 
            
            marginTop:"10%",
            marginBottom:"0%",
            marginLeft:"26%",
           alignItems:"center",
             fontSize:60, 
             fontFamily:"montserrat",
             fontWeight:700}}>
            With Destruction<br/> Comes <a style={{ 
                color:"rgb(228, 116, 59)" }}>RENOVATION</a></p>
             <p style={{ 
                 marginTop:"-2%",
                 marginLeft:"45%",
                 textAlign:"center",
                 fontSize:41,
                 fontFamily:"roboto",
                 fontStyle:"italic"}}>"Willy Lamb"</p>
    
             <div class="row" id={styles.social}>

<div class="col s7">
<h3>Follow us on</h3>
</div>

<div class="col s5">
            <a href="#" class="fa fa-facebook" id={styles.fa}></a>
            <a href="#" class="fa fa-instagram" id={styles.fa}></a>
            <a href="#" class="fa fa-linkedin" id={styles.fa}></a>
            <a href="#" class="fa fa-twitter" id={styles.fa}></a>
            
</div>

</div>

      </div>
      <div class="row">
<h4 class="title2" style={{textAlign:"left", marginBottom:"3%"}}>CONTACT</h4>
<p style={{fontSize:15,fontFamily:"montserrat",fontWeight:500,letterSpacing:"0.1em"}}>KEEP IN TOUCH</p>
<div class="col s6">
  <h3>LET'S START A FRUITFUL CONVERSATION.</h3>
  <div class="col s2">
      <ul>
      <li className={styles.icon}>
          <i class="medium material-icons">phone_iphone</i>
         
     </li>
      <li className={styles.icon}>
          <i class="medium material-icons" >email</i>
          
     </li>
      <li className={styles.icon}>
          <i class="medium material-icons" >location_on</i>    
     </li>
      </ul>
      </div>
      <div class="col s4 push-s1">
          <ul>
              <li className={styles.itxt}>
                  <h3 style={{ 
                      fontSize:25,
                    fontfamily:"Montserrat",
                    fontweight: 700}}>Call Us 24/7<br/></h3><p>(+1)800-600-2323
           </p></li>
              <li className={styles.itxt}>
                  <h3 style={{ 
                      fontSize:25,
                    fontfamily:"Montserrat",
                    fontweight: 700}}>Mail Us 24/7 </h3><p>Info@rengebxweb.co.in</p></li>
              <li className={styles.itxt}>
                  <h3 style={{ fontSize:25,
                    fontfamily:"Montserrat",
                    fontweight: 700}}>Visit Us 24/7</h3><p> 1508 North Street, AustinTexas,US</p></li>
          </ul>
      </div>
 
</div>

            <div class="col s6 push-s1" >
            <Image 
            src={pic2}
            width={597}
            height={695}
            style={{
                marginTop:"8%",
                
            }}
            />
            </div>

      </div>
      <div className={styles.connect}>
          
            <h3  style={{
             marginLeft:"4%" ,marginTop:"auto"}}>Do you want to renovate <br/>your house or office ?</h3>
            
              <div class="right"  style={{
             marginRight:"4%" }}>
               <button class="btn" style={{
               background:"rgb(227, 137, 91)"
        ,width:"200px",height:"50px" }}>Contact Us</button>
        </div>
        </div>
          </div>
      
    )
  }