import styles from "../styles/Home.module.css"
const Cards = () =>{
    return (
        <div class="cardscolumn"> 
         <ul>
        <li class="cards"><h1 id="digits">350+</h1> Trusted Clients</li>
        <li class="cards"><h1 id="digits">215+</h1>Finished Project</li>
        <li class="cards"><h1 id="digits">15+</h1> Years Of Experience</li>
    </ul>
</div>
    )
}
export default Cards