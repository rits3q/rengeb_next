const Cards2 = () =>{
    return (
        <div class="aboutcolumn"> 
        <h4>WHO WE ARE</h4>
        <h3>Hey guys, have a look at my work and designs on my website.<br/>Don't forget to look into my previous project.
  </h3>
        <h5>We basically provide five types of services i.e., Renovation, Plastering ,Masonry ,Flooring and Roofing.
            We are proud to deliver projects which meets the present day needs for housing
            <br/> and infrastructurewithout compromising the ability of future generations.
        <br/>We believe each commercial building renovation project must be planned and executed carefully.
        </h5>
        
        <ul>
        <button class="btn #ff5722 deep-orange">READ MORE</button> 
        </ul>
</div>
    )
}
export default Cards2