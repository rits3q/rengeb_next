
import styles from '../components/Services.module.css'
import ReactPlayer from 'react-player'
export default function Services() {
  return (
     <div className={styles.container}>
                    
         <div className={styles.ourservices}> 
          <h1 className={styles.service}>OUR SERVICES</h1>
          <h5 id={styles.abt3}> WHAT WE CAN DO FOR YOU </h5>
          <h id={styles.abt4}>
          <h3>Hey guys, have a look at my work and designs on my website.<br/>Don't forget to look into my previous project.
    </h3>
          <h5>We basically provide five types of services i.e., Renovation, Plastering ,Masonry ,Flooring and Roofing.
              We are proud to deliver projects which meets the present day needs for housing
              <br/> and infrastructurewithout compromising the ability of future generations.
          <br/>We believe each commercial building renovation project must be planned and executed carefully.
          </h5>
          <h5>We basically provide five types of services i.e., Renovation, Plastering ,Masonry ,Flooring and Roofing.
              We are proud to deliver projects which meets the present day needs for housing
              <br/> and infrastructurewithout compromising the ability of future generations.
          <br/>We believe each commercial building renovation project must be planned and executed carefully.
          </h5>
          </h>
  </div>
  <div class="video-container">
      <ReactPlayer width="853" height="480" url='https://www.youtube.com/watch?v=GwXjdZNkCR0' />
    </div>
    {/* <div class="video-container">
        <iframe width="853" height="480" src="//www.youtube.com/embed/Q8TXgCzxEnw?rel=0" frameborder="0" allowfullscreen></iframe>
      </div> */}
     
    </div>
  )
}
