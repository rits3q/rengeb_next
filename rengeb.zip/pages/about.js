
import styles from '../styles/Home.module.css'
import Aboutus from '../components/Aboutus'
export default function About() {
  return (
     <div className={styles.container}>
            <Aboutus />         
</div>
    
  )
}
